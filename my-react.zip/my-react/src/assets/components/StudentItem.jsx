import React from "react";
import "./StudentItem.css"
import StudentTag from "./StudentTag";
import {useState} from "react";

function StudentItem(props) {
    const surename = props.surename;
    const age = props.age;
    const [name, setName] = useState(props.name);
    
    const nameHandler = () => {
        setName("Changed")
    }
    
    return (
        <div className="StudentItem">
            <div>{name}</div>
            <div>{surename}</div>
            <div>{age}</div>
            <StudentTag tagAge={age}/>
            <button onClick={nameHandler}>Click</button>
        </div>
    )
}

// const StudentItem = () => {
//     let name = "Nattapon";
//     let surename = "Trakulbangkla";
//     let age = "27";

//     return (
//         <div className="StudentItem">
//             <div>{name}</div>
//             <div>{surename}</div>
//             <div>{age}</div>
//         </div>
//     )
// }

// class StudentItem extends React.Component {
//     render() {
//         let name = "Nattapon";
//         let surename = "Trakulbangkla";
//         let age = "27";

//         this.props.name

//         return (
//             <div className="StudentItem">
//                 <div>{name}</div>
//                 <div>{surename}</div>
//                 <div>{age}</div>
//                 <div>Class Component</div>
//             </div>
//         )
//     }
// }

export default StudentItem;