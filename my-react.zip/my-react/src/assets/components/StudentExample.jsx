import React from "react";

function StudentExample(props) {
    console.log("Children",props.Children);

    return (
        <div>
            StudentExample = {" "}
            {React.Children.map(props.Children, (child) => 
            React.cloneElement(child,{style:{color:"yello", fontSize:"30px"}})
            )}
        </div>
    );
}

export default StudentExample;