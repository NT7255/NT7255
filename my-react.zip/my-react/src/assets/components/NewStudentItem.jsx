import React, { useState } from "react";
import "./NewStudentItem.css";

const NewStudentItem = ({ onAddStudent }) => {
    const [curName, setCurname] = useState("");
    const [curSurname, setCurSurname] = useState("");
    const [curAge, setCurAge] = useState("");

    const nameChangeHandler = (event) => {
        console.log(typeof event.target.value)
        setCurname(event.target.value);
    };

    const surnameChangeHandler = (event) => {
        console.log(typeof event.target.value)
        setCurSurname(event.target.value);
    };

    const ageChangeHandler = (event) => {
        console.log(typeof event.target.value)
        setCurAge(event.target.value);
    };

    const submitHandler = (event) => {
        event.preventDefault();
        const newStudent = {
            name: curName,
            surname: curSurname,
            age: Number(curAge),
        }

        onAddStudent(newStudent);

        setCurname("")
        setCurSurname("")
        setCurAge("")
    }

    return (
        <form onSubmit={submitHandler}>
            <div className="NewStudentContainer">
                <div className="StudentInput">
                    <label>Name</label>
                    <input value={curName} onChange={nameChangeHandler} type="text" />
                </div>
                <div className="StudentInput">
                    <label>Surname</label>
                    <input value={curSurname} onChange={surnameChangeHandler} type="text" />
                </div>
                <div className="StudentInput">
                    <label>Age</label>
                    <input value={curAge} onChange={ageChangeHandler} type="number" min="0" max="100" step="2" />
                </div>
            </div>
            <div className="SubmitButton">
                <button type="submit">Add Student</button>
            </div>
        </form>
    )
}

export default NewStudentItem;