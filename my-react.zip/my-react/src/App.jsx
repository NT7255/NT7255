import './App.css'
import StudentItem from './assets/components/StudentItem';
import StudentExample from './assets/components/StudentExample';
import StudentTag from './assets/components/StudentTag';
import {useState} from "react";
import NewStudentItem from "./assets/components/NewStudentItem";

function App() {
  const studentlist = [
      {name:"Nattapon", surename:"Terng", age:65},
      {name:"Nuntavat", surename:"Conan", age:50},
      {name:"Putanon", surename:"Phu", age:25},
      {name:"Tanakorn", surename:"N'Hong", age:24}
    ]

  const [status, setStatus] = useState("Available")

  const clickHandler = () => {
    setStatus("Busy")
    console.log("status", status)
  }

  const addStudentHandler = (newStudent) => {
    const newStudentItem = {
      ...newStudent,
      id: Math.random().toString(),
    }
    console.log(newStudentItem)
  }

  return (
    <div className="App">
      <h1>Vite + React</h1>
      <NewStudentItem onAddStudent={addStudentHandler}/>
      <StudentItem name={studentlist[0].name} surename={studentlist[0].surename} age={studentlist[0].age}/>
      <StudentItem name={studentlist[1].name} surename={studentlist[1].surename} age={studentlist[1].age}/>
      <StudentItem name={studentlist[2].name} surename={studentlist[2].surename} age={studentlist[2].age}/>
      <StudentItem name={studentlist[3].name} surename={studentlist[3].surename} age={studentlist[3].age}/>
      <h3>Status: {status}</h3>
      <button onClick={clickHandler}>Click Me</button>
    </div>
  );
}

export default App;

// function App() {
//       const Student1 = {name:"Nattapon", surename:"Terng", age:"27"}
//       const Student2 = {name:"Nuntavat", surename:"Conam", age:"26"}
//       const Student3 = {name:"Putanon", surename:"Phu", age:"25"}
//       const Student4 = {name:"Tanakorn", surename:"N'Hong", age:"24"}
//   return (
//     <div className="App">
//       <h1>Vite + React</h1>
//       <StudentItem name={Student1.name} surename={Student1.surename} age={Student1.age}/>
//       <StudentItem name={Student2.name} surename={Student2.surename} age={Student2.age}/>
//       <StudentItem name={Student3.name} surename={Student3.surename} age={Student3.age}/>
//       <StudentItem name={Student4.name} surename={Student4.surename} age={Student4.age}/>
//     </div>
//   )
// }

//--------------------------------------------------------------------------------------------------------

// function App() {
//   return (
//     <div className="App">
//       <h1>Vite + React</h1>
//       <StudentItem name="Nattapon" surename="Terng" age="27"/>
//       <StudentItem name="Nuntavat" surename="Conam" age="26" />
//       <StudentItem name="Putanon" surename="Phu" age="25" />
//       <StudentItem name="Tanakorn" surename="N'Hong" age="24"/>
//     </div>
//   )
// }